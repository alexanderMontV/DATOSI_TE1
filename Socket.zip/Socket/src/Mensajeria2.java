import javax.swing.*;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.net.ServerSocket;

public class Mensajeria2  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MarcoServidor mimarco=new MarcoServidor();
		
		mimarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
	}	
}

class MarcoServidor extends JFrame implements Runnable {
	
	public MarcoServidor(){
		
		setBounds(1200,300,280,350);
			
		JPanel milamina= new JPanel();
		
		milamina.setLayout(new BorderLayout());
		
		areatexto=new JTextArea();
		
		milamina.add(areatexto,BorderLayout.CENTER);
		
		add(milamina);
		
		setVisible(true);

		Thread escucho = new Thread(this);

		escucho.start();
		
		}
	
	private	JTextArea areatexto;

	@Override
	public void run() {
		try {
			ServerSocket server = new ServerSocket(9999);

			String ip, mensaje;

			paqueteDato paqueteR;

			while (true) {

				Socket mysocket = server.accept();

				ObjectInputStream paqueteEntrada = new ObjectInputStream(mysocket.getInputStream()); //Flujo de datos usando mysocket

				paqueteR = (paqueteDato) paqueteEntrada.readObject(); //Leer el flujo de datos como Object

				ip = paqueteR.getIp(); //Obtiene la ip y el mensaje con métodos getter y setter

				mensaje = paqueteR.getMensaje();

				areatexto.append("\n" + ip + "\n" + mensaje);

				Socket enviaDestinatario = new Socket(ip, 9090);

				ObjectOutputStream paqueteE = new ObjectOutputStream(enviaDestinatario.getOutputStream());

				paqueteE.writeObject(paqueteR);

				paqueteE.close();

				enviaDestinatario.close();

				mysocket.close();

				/*DataInputStream mensaje = new DataInputStream(mysocket.getInputStream());

				String mensajeR = mensaje.readUTF();

				areatexto.append("\n" + mensajeR);

				mensaje.close();*/
			}

		} catch (IOException e) {
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
